
//console.log("5+15+Azeem");
// var student = "5+5+Fahad";
// console.log(student);

// Cannot be a reserved keyword
// should be a meaningful
// cant start with a number > 1name
// cant contain space and hyphen -
// are case-sensitive 