// 1. Primitives Types 
    // String, Number, Boolean, Undefined, null 

    var myName = "Fahad";
    var age = 30;
    var isDefined = undefined;
    var selectCourse = null;