// const myname = "Fahad";
// // myname = "Fahad";
// console.log(myname);

const pi = 3.14;
console.log(pi);