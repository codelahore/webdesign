// var student, age;
// student = "Fahad";
// //age = 18;
// // console.log(student +' '+age)
// alert('Hello' + student);
// age = prompt('Please enter your age');//20
// console.log(student+' age id '+age);

// Operators
// var totalDistance, distanceFahad, distanceHanan;
// totalDistance = 20;

// distanceFahad = totalDistance + 12;
// distanceHanan = totalDistance - 8;
// console.log(distanceFahad); //32
// console.log(distanceHanan);//12
// console.log(distanceFahad * 2); //64
// console.log(distanceFahad / 2); // 16

//logical operators
// var distanceToKics, distanceToHome;
// distanceToKics = 20;
// distanceToHome = 5;

// var far = distanceToKics < distanceToHome; // 20 < 5
// console.log(far); // false // 0
// var hudaLunch = "Piza";
// var hudaBreakfast = "Milk with Egg and Hunny";
// console.log('Huda Breakfast is '+hudaBreakfast+' and huda\'s lunch '+ hudaLunch);

// var grade;
// grade = 55;

// if(grade < 50){
//     console.log('You can not go to next class.');
// } else if (grade >= 50 && grade < 60) {
//     console.log('You can not go to next class but you can enter the exam');
// } else {
//     console.log('You can go to next class');
// }
